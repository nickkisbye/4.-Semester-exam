module.exports = {
    connection: {
        host: 'localhost',
        database: 'webshop',
        user: 'root',
        password: '',
        sessionSecret: 'aF054ffsdCæf_%#BdO0p',
    }
}