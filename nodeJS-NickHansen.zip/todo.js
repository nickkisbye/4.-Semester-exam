/**
 * Sockets impl -> et "tool" der notifikerer admin om hvor folk er på siden.
 * Betalingsflow på varer: slet varer fra shopping card -> stripe integration
 */